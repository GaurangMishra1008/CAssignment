#include <stdio.h>

int main() {
    int i = 45;
    while (i <= 89) {
        printf("%d ", i);
        i++;
    }
    return 0;
}
