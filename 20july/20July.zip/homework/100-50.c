#include <stdio.h>

int main() {
    int i = 100;
    while (i >= 50) {
        printf("%d ", i);
        i--;
    }
    return 0;
}
