#include <stdio.h>

int main() {
    int i = 50;

    while (i <= 100) {
        printf("%d ", i);
        i++;
    }

    return 0;
}
