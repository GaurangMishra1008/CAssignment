#include<stdio.h>
int main()
{
    int num=1;
    while(num<101)
    {
        if(num%2==0)
			printf("%d ",num);

		// increasing loop counter by 1
		num++;
    }return 0;
    }


