#include<stdio.h>
int main()
{
    int num=0;
    while(num<101)
    {
        if(num%2!=0)
			{
printf("%d ",num);
			}


		num++;
    }return 0;
    }




