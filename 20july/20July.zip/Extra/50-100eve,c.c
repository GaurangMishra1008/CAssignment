#include<stdio.h>
int main()
{
    int num=50;
    while(num<1001)
    {
        if(num%2==0)
			printf("%d ",num);

		// increasing loop counter by 1
		num++;
    }return 0;
    }



