
#include<stdio.h>
int main()
{
    int i,j=1;
    for(int a=0;a<=2;a++)
    {
        for(j=1;j<=4;j++)
                printf("%d",j);
        printf("\n");
    }
}
