

#include<stdio.h>
int main()
{
    int num=100;
    for(;num>=1;num--)
    {
        if(!(num%2==0))
            printf("%d ",num);
    }
    return 0;
}
